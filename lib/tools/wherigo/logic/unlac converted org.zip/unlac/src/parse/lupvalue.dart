import 'b_object.dart';

class LUpvalue extends BObject {
  bool instack;
  int idx;
  String? name;

  @override
  bool operator ==(Object other) {
    if (other is LUpvalue) {
      return instack == other.instack &&
          idx == other.idx &&
          (name == other.name || (name != null && name == other.name));
    }
    return false;
  }
}

