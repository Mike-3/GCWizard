abstract class BObject {
  
}

