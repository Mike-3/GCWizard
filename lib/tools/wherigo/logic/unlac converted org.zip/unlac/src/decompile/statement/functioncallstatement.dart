import 'package:unluac/decompile/decompiler.dart';
import 'package:unluac/decompile/output.dart';
import 'package:unluac/decompile/expression/function_call.dart';

class FunctionCallStatement extends Statement {
  final FunctionCall call;

  FunctionCallStatement(this.call);

  @override
  void print(Decompiler d, Output out) {
    call.print(d, out);
  }

  @override
  bool beginsWithParen() {
    return call.beginsWithParen();
  }
}