import 'package:unluac/decompile/expression.dart';
import 'package:unluac/parse.dart';
import 'package:unluac/version.dart';

class Function {
  List<Constant> constants;
  final int constantsOffset;

  Function(LFunction function)
      : constants = List<Constant>.generate(
            function.constants.length, (i) => Constant(function.constants[i])),
        constantsOffset = function.header.version == Version.LUA50 ? 250 : 256;

  bool isConstant(int register) {
    return register >= constantsOffset;
  }

  int constantIndex(int register) {
    return register - constantsOffset;
  }

  String getGlobalName(int constantIndex) {
    return constants[constantIndex].asName();
  }

  ConstantExpression getConstantExpression(int constantIndex) {
    return ConstantExpression(constants[constantIndex], constantIndex);
  }

  GlobalExpression getGlobalExpression(int constantIndex) {
    return GlobalExpression(getGlobalName(constantIndex), constantIndex);
  }
}


